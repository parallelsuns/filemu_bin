contrastValue = 1.6
brightnessValue = 0.05

function adj(color, contrast, brightness)
  output = color
  output.r = contrast * output.r - (contrast-1)/2 + brightness
  output.g = contrast * output.g - (contrast-1)/2 + brightness
  output.b = contrast * output.b - (contrast-1)/2 + brightness
  return output
  end

color = sample(x,y)
color = adj(color,contrastValue, brightnessValue)
return color