color = sample(x,y)
sum = color.r + color.g + color.b
sum = sum / 3.0
return make_color(sum,sum,sum)