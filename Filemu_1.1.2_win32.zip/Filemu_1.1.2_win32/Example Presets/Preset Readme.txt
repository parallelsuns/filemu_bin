These presets were designed for images approximately 6000x4000 pixels in size. They all contain at least one blur effect application, designed to emulate the lower visual resolution of film. 

Since the intensity of this blur effect can vary depending on image size, you may wish to modify the preset accordingly or remove the blur filter from the preset if using on images of other sizes.