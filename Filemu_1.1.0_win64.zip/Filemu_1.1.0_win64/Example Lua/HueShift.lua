hueShift = 0.05
color = sample(x,y)
color = to_hsl(color)
color.r = color.r + hueShift
color = from_hsl(color)
return color